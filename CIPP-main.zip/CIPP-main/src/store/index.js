import { store, persistor } from './store'

export { store, persistor }
