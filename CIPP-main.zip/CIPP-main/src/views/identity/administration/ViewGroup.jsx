//import React from 'react'

const ViewGroup = () => {
  return 'view group'
}

export default ViewGroup
