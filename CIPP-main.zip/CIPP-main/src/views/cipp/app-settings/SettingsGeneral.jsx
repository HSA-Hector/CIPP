import { useListTenantsQuery } from 'src/store/api/tenants.js'
import {
  useLazyExecClearCacheQuery,
  useLazyExecPermissionsAccessCheckQuery,
  useLazyExecTenantsAccessCheckQuery,
  useLazyGenericGetRequestQuery,
} from 'src/store/api/app.js'
import React, { useRef, useState } from 'react'
import { cellGenericFormatter } from 'src/components/tables/CellGenericFormat.jsx'
import { cellTableFormatter } from 'src/components/tables/CellTable.jsx'
import {
  CButton,
  CCallout,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CFormSwitch,
  CLink,
  CListGroup,
  CListGroupItem,
  CRow,
  CTable,
} from '@coreui/react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleNotch } from '@fortawesome/free-solid-svg-icons'
import CippListOffcanvas from 'src/components/utilities/CippListOffcanvas.jsx'
import { TableModalButton } from 'src/components/buttons/index.js'
import { CippTable } from 'src/components/tables/index.js'
import { TenantSelectorMultiple } from 'src/components/utilities/index.js'
import { SettingsGeneralRow } from 'src/views/cipp/app-settings/components/SettingsGeneralRow.jsx'
import CippButtonCard from 'src/components/contentcards/CippButtonCard'
import { ListGroupContentCard } from 'src/components/contentcards'

/**
 * SettingsGeneral component.
 * This method is responsible for managing general settings.
 * @returns {JSX.Element}
 */
export function SettingsGeneral() {
  const { data: tenants = [] } = useListTenantsQuery({ AllTenantSelector: false })
  const [checkPermissions, permissionsResult] = useLazyExecPermissionsAccessCheckQuery()
  const [checkGDAP, GDAPResult] = useLazyGenericGetRequestQuery()

  const [clearCache, clearCacheResult] = useLazyExecClearCacheQuery()
  const [checkAccess, accessCheckResult] = useLazyExecTenantsAccessCheckQuery()
  const [selectedTenants, setSelectedTenants] = useState([])
  const [showMaxSelected, setShowMaxSelected] = useState(false)
  const [tokenOffcanvasVisible, setTokenOffcanvasVisible] = useState(false)
  const [showExtendedInfo, setShowExtendedInfo] = useState(true)

  const maxSelected = 2
  const tenantSelectorRef = useRef(null)

  const handleSetSelectedTenants = (value) => {
    if (value.length <= maxSelected) {
      setSelectedTenants(value)
      setShowMaxSelected(false)
    } else {
      setSelectedTenants(value)
      setShowMaxSelected(true)
    }
  }

  const checkAccessColumns = [
    {
      name: 'Tenant Domain',
      selector: (row) => row['TenantName'],
      grow: 0,
      cell: cellGenericFormatter(),
    },
    {
      name: 'Result',
      selector: (row) => row['Status'],
      minWidth: '380px',
      maxWidth: '380px',
      cell: cellGenericFormatter(),
    },
    {
      name: 'Missing GDAP Roles',
      selector: (row) => row?.MissingRoles,
      cell: cellTableFormatter('MissingRoles', true, false, true),
    },
    {
      name: 'Roles available',
      selector: (row) => row?.GDAPRoles,
      cell: cellTableFormatter('GDAPRoles', false, true),
      omit: showExtendedInfo,
      exportSelector: 'GDAPRoles',
    },
  ]

  const checkGDAPColumns = [
    {
      name: 'Tenant',
      selector: (row) => row['Tenant'],
      sortable: true,
      cell: cellGenericFormatter(),
      minWidth: '200px',
      maxWidth: '200px',
    },
    {
      name: 'Error Type',
      selector: (row) => row['Type'],
      sortable: true,
      cell: cellGenericFormatter(),
      minWidth: '100px',
      maxWidth: '100px',
    },
    {
      name: 'Issue',
      selector: (row) => row?.Issue,
      sortable: true,
      cell: cellGenericFormatter(),
    },
    {
      name: 'Resolution Link',
      sortable: true,
      selector: (row) => row?.Link,
      cell: cellGenericFormatter(),
    },
    {
      name: 'Relationship ID',
      sortable: true,
      selector: (row) => row?.Relationship,
      cell: cellGenericFormatter(),
    },
  ]

  const handleCheckAccess = () => {
    const mapped = tenants.reduce(
      (current, { customerId, ...rest }) => ({
        ...current,
        [customerId]: { ...rest },
      }),
      {},
    )
    const AllTenantSelector = selectedTenants.map(
      (customerId) => mapped[customerId].defaultDomainName,
    )
    checkAccess({ tenantDomains: AllTenantSelector })
  }

  const tableProps = {
    pagination: false,
    actions: [
      <CFormSwitch
        label="Show Extended Info"
        onChange={(e) => {
          //console.log(e)
          setShowExtendedInfo(!e.target.checked)
        }}
        key={'Show Extended Info'}
      />,
    ],
  }
  const permissionsCheckButton = (
    <CButton
      onClick={() => checkPermissions()}
      disabled={permissionsResult.isFetching}
      className="me-2"
    >
      {permissionsResult.isFetching && (
        <FontAwesomeIcon icon={faCircleNotch} spin className="me-2" size="1x" />
      )}
      Run Permissions Check
    </CButton>
  )

  const gdapButton = (
    <CButton
      onClick={() => checkGDAP({ path: '/api/ExecAccessChecks?GDAP=true' })}
      disabled={GDAPResult.isFetching}
      className="me-2"
    >
      {GDAPResult.isFetching && (
        <FontAwesomeIcon icon={faCircleNotch} spin className="me-2" size="1x" />
      )}
      Run GDAP Check
    </CButton>
  )

  const tenantAccessCheckButton = (
    <CButton
      onClick={() => handleCheckAccess()}
      disabled={accessCheckResult.isFetching || selectedTenants.length < 1}
    >
      {accessCheckResult.isFetching && (
        <FontAwesomeIcon icon={faCircleNotch} spin className="me-2" size="1x" />
      )}
      Run access check
    </CButton>
  )
  return (
    <div>
      <CRow className="mb-3">
        <CCol>
          <SettingsGeneralRow />
        </CCol>
      </CRow>
      <CRow className="mb-3">
        <CCol className="mb-3" xl={6} md={12}>
          <CippButtonCard
            title="Permissions Check"
            titleType="big"
            isFetching={permissionsResult.isFetching}
            CardButton={permissionsCheckButton}
          >
            <p>Click the button below to start a permissions check.</p>

            {permissionsResult.isSuccess && (
              <>
                {permissionsResult.data.Results?.AccessTokenDetails?.Name !== '' && (
                  <>
                    <CTable>
                      <thead>
                        <tr>
                          <th>Authentication User</th>
                          <th>Authentication IP</th>
                          <th>Application</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>
                            {permissionsResult.data.Results?.AccessTokenDetails?.UserPrincipalName}
                          </td>
                          <td>{permissionsResult.data.Results?.AccessTokenDetails?.IPAddress}</td>
                          <td>
                            <a
                              target="_blank"
                              href={`https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/Overview/appId/${permissionsResult.data.Results?.AccessTokenDetails?.AppId}/isMSAApp/`}
                              rel="noreferrer"
                            >
                              Link
                            </a>
                          </td>
                        </tr>
                      </tbody>
                    </CTable>
                  </>
                )}
                <CRow>
                  <CCol>
                    <CCallout color="success">
                      {permissionsResult.data.Results?.Messages && (
                        <>
                          {permissionsResult.data.Results?.Messages?.map((m, idx) => (
                            <div key={idx}>{m}</div>
                          ))}
                        </>
                      )}
                    </CCallout>
                  </CCol>
                  <CCol>
                    {(permissionsResult.data.Results?.ErrorMessages?.length > 0 ||
                      permissionsResult.data.Results?.MissingPermissions.length > 0) && (
                      <CCallout color="danger">
                        <>
                          {permissionsResult.data.Results?.ErrorMessages?.map((m, idx) => (
                            <div key={idx}>{m}</div>
                          ))}
                        </>
                        {permissionsResult.data.Results?.MissingPermissions.length > 0 && (
                          <>
                            Your Secure Application Model is missing the following permissions. See
                            the documentation on how to add permissions{' '}
                            <a
                              target="_blank"
                              rel="noreferrer"
                              href="https://docs.cipp.app/setup/installation/permissions#manual-permissions"
                            >
                              here
                            </a>
                            .
                            <CListGroup flush>
                              {permissionsResult.data.Results?.MissingPermissions?.map(
                                (r, index) => (
                                  <CListGroupItem key={index}>{r}</CListGroupItem>
                                ),
                              )}
                            </CListGroup>
                          </>
                        )}
                      </CCallout>
                    )}
                  </CCol>
                </CRow>
              </>
            )}
          </CippButtonCard>
        </CCol>
        <CCol xl={6} md={12} className="mb-3">
          <CippButtonCard
            title="GDAP Check"
            titleType="big"
            isFetching={GDAPResult.isFetching}
            CardButton={gdapButton}
          >
            <p>Click the button below to start a check for general GDAP settings.</p>

            {GDAPResult.isSuccess && (
              <>
                <TableModalButton
                  className="mb-3 me-2"
                  data={GDAPResult.data.Results?.Memberships?.filter(
                    (p) => p['@odata.type'] == '#microsoft.graph.group',
                  )}
                  title="Groups"
                />
                <TableModalButton
                  className="mb-3"
                  data={GDAPResult.data.Results?.Memberships?.filter(
                    (p) => p['@odata.type'] == '#microsoft.graph.directoryRole',
                  )}
                  title="Roles"
                />
              </>
            )}
            <CRow>
              <CCol>
                {GDAPResult.isSuccess && GDAPResult.data.Results.GDAPIssues?.length > 0 && (
                  <>
                    {GDAPResult.data.Results.GDAPIssues?.filter((e) => e.Type === 'Error').length >
                      0 && (
                      <CCallout color="danger">
                        Relationship errors detected. Review the table below for more details.
                      </CCallout>
                    )}
                    {GDAPResult.data.Results.GDAPIssues?.filter((e) => e.Type === 'Warning')
                      .length > 0 && (
                      <CCallout color="warning">
                        Relationship warnings detected. Review the table below for more details.
                      </CCallout>
                    )}
                    <CippTable
                      showFilter={true}
                      reportName="none"
                      columns={checkGDAPColumns}
                      data={GDAPResult.data.Results.GDAPIssues}
                      filterlist={[
                        {
                          filterName: 'Errors',
                          filter: 'Complex: Type eq Error',
                        },
                        {
                          filterName: 'Warnings',
                          filter: 'Complex: Type eq Warning',
                        },
                      ]}
                      isModal={true}
                    />
                  </>
                )}
                {GDAPResult.isSuccess && GDAPResult.data.Results.GDAPIssues?.length === 0 && (
                  <CCallout color="success">
                    No relationships with issues found. Please perform a Permissions Check or Tenant
                    Access Check if you are experiencing issues.
                  </CCallout>
                )}
              </CCol>
            </CRow>
          </CippButtonCard>
        </CCol>
      </CRow>
      <CRow className="mb-3">
        <CCol>
          <CippButtonCard
            title={'Run Tenant Access Check'}
            titleType={'big'}
            isFetching={accessCheckResult.isFetching}
            CardButton={tenantAccessCheckButton}
          >
            <CRow className="mb-3">
              <CCol>
                <div className="mb-3">
                  Click the button below to start a tenant access check. You can select multiple,
                  but a maximum of {maxSelected + 1} tenants is recommended.
                </div>

                <TenantSelectorMultiple
                  ref={tenantSelectorRef}
                  values={selectedTenants}
                  onChange={(value) =>
                    handleSetSelectedTenants(
                      value.map((val) => {
                        return val.value
                      }),
                    )
                  }
                />
                {showMaxSelected && (
                  <CCallout color="warning">
                    A maximum of {maxSelected + 1} tenants is recommended.
                  </CCallout>
                )}
              </CCol>
            </CRow>

            <CRow className="mb-3">
              <CCol></CCol>
            </CRow>
            <CRow>
              <CCol>
                {accessCheckResult.isSuccess && (
                  <CippTable
                    showFilter={false}
                    disablePDFExport={true}
                    disableCSVExport={true}
                    reportName="none"
                    columns={checkAccessColumns}
                    tableProps={tableProps}
                    data={accessCheckResult.data.Results}
                    dynamicColumns={false}
                  />
                )}
              </CCol>
            </CRow>
          </CippButtonCard>
        </CCol>
      </CRow>
    </div>
  )
}
