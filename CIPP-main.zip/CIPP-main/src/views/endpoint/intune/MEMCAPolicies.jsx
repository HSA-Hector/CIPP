import React from 'react'

const IntuneCAPolicies = (props) => {
  return (
    <div>
      <h3>Endpoint Manager - CA Policies</h3>
    </div>
  )
}

export default IntuneCAPolicies
